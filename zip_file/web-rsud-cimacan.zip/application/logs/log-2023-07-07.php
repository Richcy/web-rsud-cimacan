<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-07 10:38:56 --> Severity: Warning --> Undefined variable $category C:\xampp\htdocs\web-rsud-cimacan\application\controllers\Cimanews.php 34
ERROR - 2023-07-07 10:38:56 --> Severity: Warning --> Undefined array key 0 C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\top-bar.php 11
ERROR - 2023-07-07 10:38:56 --> Severity: Warning --> Attempt to read property "content" on null C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\top-bar.php 11
ERROR - 2023-07-07 10:45:33 --> Severity: Warning --> Undefined array key 0 C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\top-bar.php 11
ERROR - 2023-07-07 10:45:33 --> Severity: Warning --> Attempt to read property "content" on null C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\top-bar.php 11
ERROR - 2023-07-07 10:49:26 --> Severity: Warning --> Undefined array key 0 C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\top-bar.php 11
ERROR - 2023-07-07 10:49:26 --> Severity: Warning --> Attempt to read property "content" on null C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\top-bar.php 11
ERROR - 2023-07-07 10:49:42 --> Severity: Warning --> Undefined array key 0 C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\top-bar.php 11
ERROR - 2023-07-07 10:49:42 --> Severity: Warning --> Attempt to read property "content" on null C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\top-bar.php 11
ERROR - 2023-07-07 10:49:53 --> Severity: Warning --> Undefined array key 0 C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\top-bar.php 11
ERROR - 2023-07-07 10:49:53 --> Severity: Warning --> Attempt to read property "content" on null C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\top-bar.php 11
ERROR - 2023-07-07 10:50:15 --> Severity: Warning --> Undefined array key 0 C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\top-bar.php 11
ERROR - 2023-07-07 10:50:15 --> Severity: Warning --> Attempt to read property "content" on null C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\top-bar.php 11
ERROR - 2023-07-07 11:08:51 --> Severity: Warning --> Undefined array key 0 C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\top-bar.php 11
ERROR - 2023-07-07 11:08:51 --> Severity: Warning --> Attempt to read property "content" on null C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\top-bar.php 11
ERROR - 2023-07-07 13:49:10 --> Severity: Warning --> Undefined array key 0 C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\top-bar.php 11
ERROR - 2023-07-07 13:49:10 --> Severity: Warning --> Attempt to read property "content" on null C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\top-bar.php 11
