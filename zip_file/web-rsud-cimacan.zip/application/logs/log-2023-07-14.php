<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-14 10:02:07 --> Severity: Warning --> Undefined property: stdClass::$start_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:02:07 --> Severity: Warning --> Undefined property: stdClass::$end_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:02:07 --> Severity: Warning --> Undefined property: stdClass::$start_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:02:07 --> Severity: Warning --> Undefined property: stdClass::$end_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:02:07 --> Severity: Warning --> Undefined property: stdClass::$start_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:02:07 --> Severity: Warning --> Undefined property: stdClass::$end_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:10:00 --> Severity: Warning --> Undefined property: stdClass::$start_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:10:00 --> Severity: Warning --> Undefined property: stdClass::$end_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:10:00 --> Severity: Warning --> Undefined property: stdClass::$start_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:10:00 --> Severity: Warning --> Undefined property: stdClass::$end_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:10:00 --> Severity: Warning --> Undefined property: stdClass::$start_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:10:00 --> Severity: Warning --> Undefined property: stdClass::$end_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:10:12 --> Severity: Warning --> Undefined property: stdClass::$start_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:10:12 --> Severity: Warning --> Undefined property: stdClass::$end_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:10:12 --> Severity: Warning --> Undefined property: stdClass::$start_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:10:12 --> Severity: Warning --> Undefined property: stdClass::$end_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:10:12 --> Severity: Warning --> Undefined property: stdClass::$start_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:10:12 --> Severity: Warning --> Undefined property: stdClass::$end_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:10:44 --> Severity: Warning --> Undefined property: stdClass::$start_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:10:44 --> Severity: Warning --> Undefined property: stdClass::$end_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:10:44 --> Severity: Warning --> Undefined property: stdClass::$start_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:10:44 --> Severity: Warning --> Undefined property: stdClass::$end_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:10:44 --> Severity: Warning --> Undefined property: stdClass::$start_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:10:44 --> Severity: Warning --> Undefined property: stdClass::$end_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:12:40 --> Severity: Warning --> Undefined property: stdClass::$start_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:12:40 --> Severity: Warning --> Undefined property: stdClass::$end_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:12:40 --> Severity: Warning --> Undefined property: stdClass::$start_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:12:40 --> Severity: Warning --> Undefined property: stdClass::$end_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:12:40 --> Severity: Warning --> Undefined property: stdClass::$start_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:12:40 --> Severity: Warning --> Undefined property: stdClass::$end_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:21:21 --> Severity: Warning --> Undefined property: stdClass::$start_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:21:21 --> Severity: Warning --> Undefined property: stdClass::$end_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:21:21 --> Severity: Warning --> Undefined property: stdClass::$start_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:21:21 --> Severity: Warning --> Undefined property: stdClass::$end_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:21:21 --> Severity: Warning --> Undefined property: stdClass::$start_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:21:21 --> Severity: Warning --> Undefined property: stdClass::$end_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:26:20 --> Severity: Warning --> Undefined property: stdClass::$start_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:26:20 --> Severity: Warning --> Undefined property: stdClass::$end_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:26:20 --> Severity: Warning --> Undefined property: stdClass::$start_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:26:20 --> Severity: Warning --> Undefined property: stdClass::$end_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:26:20 --> Severity: Warning --> Undefined property: stdClass::$start_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:26:20 --> Severity: Warning --> Undefined property: stdClass::$end_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:30:14 --> Severity: Warning --> Undefined property: stdClass::$start_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:30:14 --> Severity: Warning --> Undefined property: stdClass::$end_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:30:14 --> Severity: Warning --> Undefined property: stdClass::$start_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:30:14 --> Severity: Warning --> Undefined property: stdClass::$end_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:30:14 --> Severity: Warning --> Undefined property: stdClass::$start_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:30:14 --> Severity: Warning --> Undefined property: stdClass::$end_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:31:15 --> Severity: Warning --> Undefined array key 0 C:\xampp\htdocs\web-rsud-cimacan\application\controllers\Rehab_medik.php 26
ERROR - 2023-07-14 10:31:15 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\web-rsud-cimacan\application\controllers\Rehab_medik.php 26
ERROR - 2023-07-14 10:31:15 --> Severity: Warning --> Undefined array key 0 C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\rehab_medik.php 75
ERROR - 2023-07-14 10:31:15 --> Severity: Warning --> Attempt to read property "description" on null C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\rehab_medik.php 75
ERROR - 2023-07-14 10:43:31 --> Severity: Warning --> Undefined property: stdClass::$start_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:43:31 --> Severity: Warning --> Undefined property: stdClass::$end_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:43:31 --> Severity: Warning --> Undefined property: stdClass::$start_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:43:31 --> Severity: Warning --> Undefined property: stdClass::$end_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:43:31 --> Severity: Warning --> Undefined property: stdClass::$start_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
ERROR - 2023-07-14 10:43:31 --> Severity: Warning --> Undefined property: stdClass::$end_date C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\career.php 106
