<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-06 11:31:33 --> Severity: Warning --> Undefined variable $category C:\xampp\htdocs\web-rsud-cimacan\application\controllers\Cimanews.php 34
ERROR - 2023-07-06 11:31:33 --> Severity: Warning --> Undefined array key 0 C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\top-bar.php 11
ERROR - 2023-07-06 11:31:33 --> Severity: Warning --> Attempt to read property "content" on null C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\top-bar.php 11
ERROR - 2023-07-06 11:31:54 --> Severity: error --> Exception: syntax error, unexpected token "public" C:\xampp\htdocs\web-rsud-cimacan\application\models\M_Cimanews.php 127
ERROR - 2023-07-06 11:34:18 --> Severity: error --> Exception: syntax error, unexpected token "public" C:\xampp\htdocs\web-rsud-cimacan\application\models\M_Cimanews.php 127
ERROR - 2023-07-06 11:34:52 --> Severity: error --> Exception: syntax error, unexpected token "public" C:\xampp\htdocs\web-rsud-cimacan\application\models\M_Cimanews.php 127
ERROR - 2023-07-06 11:43:37 --> Severity: error --> Exception: syntax error, unexpected token "public" C:\xampp\htdocs\web-rsud-cimacan\application\models\M_Cimanews.php 127
ERROR - 2023-07-06 11:45:22 --> Severity: error --> Exception: syntax error, unexpected token "public" C:\xampp\htdocs\web-rsud-cimacan\application\models\M_Cimanews.php 127
ERROR - 2023-07-06 11:47:20 --> Severity: error --> Exception: syntax error, unexpected token "public" C:\xampp\htdocs\web-rsud-cimacan\application\models\M_Cimanews.php 127
ERROR - 2023-07-06 11:47:45 --> Severity: error --> Exception: syntax error, unexpected token "public" C:\xampp\htdocs\web-rsud-cimacan\application\models\M_Cimanews.php 127
ERROR - 2023-07-06 11:49:13 --> Severity: error --> Exception: syntax error, unexpected variable "$s", expecting ")" C:\xampp\htdocs\web-rsud-cimacan\application\models\M_Cimanews.php 112
ERROR - 2023-07-06 11:50:31 --> Severity: Warning --> Undefined variable $category C:\xampp\htdocs\web-rsud-cimacan\application\controllers\Cimanews.php 34
ERROR - 2023-07-06 11:50:31 --> Severity: Warning --> Undefined array key 0 C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\top-bar.php 11
ERROR - 2023-07-06 11:50:31 --> Severity: Warning --> Attempt to read property "content" on null C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\top-bar.php 11
