<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-12 08:14:37 --> Unable to set database connection charset: utf8
ERROR - 2023-07-12 08:14:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it C:\xampp\htdocs\web-rsud-cimacan\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2023-07-12 08:14:44 --> Unable to connect to the database
ERROR - 2023-07-12 10:40:50 --> Severity: error --> Exception: syntax error, unexpected token "as" C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\articles.php 65
ERROR - 2023-07-12 10:40:51 --> Severity: error --> Exception: syntax error, unexpected token "as" C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\articles.php 65
ERROR - 2023-07-12 10:43:41 --> Severity: error --> Exception: Unmatched '}' C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\articles.php 112
ERROR - 2023-07-12 10:43:41 --> Severity: error --> Exception: Unmatched '}' C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\articles.php 112
ERROR - 2023-07-12 10:44:14 --> Severity: Warning --> Attempt to read property "title" on array C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\articles.php 68
ERROR - 2023-07-12 10:44:14 --> Severity: Warning --> Attempt to read property "id" on array C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\articles.php 72
ERROR - 2023-07-12 10:44:14 --> Severity: Warning --> Attempt to read property "img" on array C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\articles.php 72
ERROR - 2023-07-12 10:44:14 --> Severity: Warning --> Attempt to read property "title" on array C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\articles.php 74
ERROR - 2023-07-12 10:44:14 --> Severity: Warning --> Attempt to read property "id" on array C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\articles.php 79
ERROR - 2023-07-12 10:44:14 --> Severity: Warning --> Attempt to read property "title" on array C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\articles.php 80
ERROR - 2023-07-12 10:44:14 --> Severity: Warning --> Attempt to read property "author" on array C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\articles.php 83
ERROR - 2023-07-12 10:44:14 --> Severity: Warning --> Attempt to read property "sub_desc" on array C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\articles.php 86
ERROR - 2023-07-12 10:44:14 --> Severity: Warning --> Attempt to read property "description" on array C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\articles.php 86
ERROR - 2023-07-12 10:44:14 --> Severity: Warning --> Attempt to read property "create_date" on array C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\articles.php 90
ERROR - 2023-07-12 10:44:14 --> Severity: Warning --> Attempt to read property "category_name" on array C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\articles.php 94
ERROR - 2023-07-12 10:44:15 --> Severity: Warning --> Attempt to read property "title" on array C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\articles.php 68
ERROR - 2023-07-12 10:44:15 --> Severity: Warning --> Attempt to read property "id" on array C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\articles.php 72
ERROR - 2023-07-12 10:44:15 --> Severity: Warning --> Attempt to read property "img" on array C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\articles.php 72
ERROR - 2023-07-12 10:44:15 --> Severity: Warning --> Attempt to read property "title" on array C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\articles.php 74
ERROR - 2023-07-12 10:44:15 --> Severity: Warning --> Attempt to read property "id" on array C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\articles.php 79
ERROR - 2023-07-12 10:44:15 --> Severity: Warning --> Attempt to read property "title" on array C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\articles.php 80
ERROR - 2023-07-12 10:44:15 --> Severity: Warning --> Attempt to read property "author" on array C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\articles.php 83
ERROR - 2023-07-12 10:44:15 --> Severity: Warning --> Attempt to read property "sub_desc" on array C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\articles.php 86
ERROR - 2023-07-12 10:44:15 --> Severity: Warning --> Attempt to read property "description" on array C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\articles.php 86
ERROR - 2023-07-12 10:44:15 --> Severity: Warning --> Attempt to read property "create_date" on array C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\articles.php 90
ERROR - 2023-07-12 10:44:15 --> Severity: Warning --> Attempt to read property "category_name" on array C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\parts\articles.php 94
