<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-20 10:22:36 --> Severity: Warning --> Undefined array key 0 C:\xampp\htdocs\web-rsud-cimacan\application\controllers\Ambulance.php 26
ERROR - 2023-07-20 10:22:36 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\web-rsud-cimacan\application\controllers\Ambulance.php 26
ERROR - 2023-07-20 10:22:36 --> Severity: Warning --> Undefined array key 0 C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\ambulance.php 75
ERROR - 2023-07-20 10:22:36 --> Severity: Warning --> Attempt to read property "description" on null C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\ambulance.php 75
