<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-22 08:37:33 --> Severity: Warning --> Undefined array key 0 C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\maklumat_pelayanan.php 107
ERROR - 2023-07-22 08:37:33 --> Severity: Warning --> Attempt to read property "img" on null C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\maklumat_pelayanan.php 107
ERROR - 2023-07-22 08:43:34 --> Severity: Warning --> Undefined array key 0 C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\maklumat_pelayanan.php 107
ERROR - 2023-07-22 08:43:34 --> Severity: Warning --> Attempt to read property "img" on null C:\xampp\htdocs\web-rsud-cimacan\application\views\fe\maklumat_pelayanan.php 107
