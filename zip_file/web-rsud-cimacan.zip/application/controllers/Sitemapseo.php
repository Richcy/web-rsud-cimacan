<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sitemapseo extends CI_Controller {

	public function index()
	{	
		$this->load->view('fe/sitemapseo');
	}

}
