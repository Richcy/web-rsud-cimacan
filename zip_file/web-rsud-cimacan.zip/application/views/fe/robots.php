<pre>
User-agent: *
Disallow: /api/

Sitemap: https://www.rsudcimacan.com/sitemap.xml
</pre>