<section id="about" class="about">
  <div class="container" data-aos="fade-up">

    <div class="section-title">
      <h2>Artikel Terbaru</h2>
    </div>

    <div class="row-ln">
      <div class="col-ln">
        <div class="ln-wrap">
          <a href="javascript:void();" class="ln-img" style="background-image: url('<?php echo base_url();?>assets/fe/img/departments-2.jpg');">
            <span style=" opacity: 0;"> 
              Article Title 1
            </span>
          </a>
          <div class="ln-content">
            <div class="row" style="height: 50px;">
              <div class="col-sm-5" style="padding-left:0;">
                <div class="ln-date">19 November 2021</div>
              </div>
            </div>
            <a href="javascript:void();" class="ln-title">
              Article Title 1
            </a>
            <div class="ln-desc">
              Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea. Quia fugiat sit in iste officiis commodi quidem hic quas.
            </div>
            <div class="ln-category">
              Category 2
            </div>
          </div>
        </div>
      </div>

      <!-- Dummy 1 -->
      <div class="col-ln">
        <div class="ln-wrap">
          <a href="javascript:void();" class="ln-img" style="background-image: url('<?php echo base_url();?>assets/fe/img/departments-5.jpg');">
            <span style=" opacity: 0;"> 
              Article Title 2
            </span>
          </a>
          <div class="ln-content">
            <div class="row" style="height: 50px;">
              <div class="col-sm-5" style="padding-left:0;">
                <div class="ln-date">19 November 2021</div>
              </div>
            </div>
            <a href="javascript:void();" class="ln-title">
              Article Title 2
            </a>
            <div class="ln-desc">
              Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea. Quia fugiat sit in iste officiis commodi quidem hic quas.
            </div>
            <div class="ln-category">
              Category 1
            </div>
          </div>
        </div>
      </div>

      <!-- Dummy 2 -->
      <div class="col-ln">
        <div class="ln-wrap">
          <a href="javascript:void();" class="ln-img" style="background-image: url('<?php echo base_url();?>assets/fe/img/departments-4.jpg');">
            <span style=" opacity: 0;"> 
              Article Title 3
            </span>
          </a>
          <div class="ln-content">
            <div class="row" style="height: 50px;">
              <div class="col-sm-5" style="padding-left:0;">
                <div class="ln-date">19 November 2021</div>
              </div>
            </div>
            <a href="javascript:void();" class="ln-title">
              Article Title 3
            </a>
            <div class="ln-desc">
              Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea. Quia fugiat sit in iste officiis commodi quidem hic quas.
            </div>
            <div class="ln-category">
              Category 3
            </div>
          </div>
        </div>
      </div>

      <!-- Dummy 3 -->
      <div class="col-ln">
        <div class="ln-wrap">
          <a href="javascript:void();" class="ln-img" style="background-image: url('<?php echo base_url();?>assets/fe/img/departments-3.jpg');">
            <span style=" opacity: 0;"> 
              Article Title 4
            </span>
          </a>
          <div class="ln-content">
            <div class="row" style="height: 50px;">
              <div class="col-sm-5" style="padding-left:0;">
                <div class="ln-date">19 November 2021</div>
              </div>
            </div>
            <a href="javascript:void();" class="ln-title">
              Article Title 4 
            </a>
            <div class="ln-desc">
              Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea. Quia fugiat sit in iste officiis commodi quidem hic quas.
            </div>
            <div class="ln-category">
              Category 1
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="le-all">
      <a href="javascript:void();">Artikel Lainnya</a>
    </div>
  </div>
</section>