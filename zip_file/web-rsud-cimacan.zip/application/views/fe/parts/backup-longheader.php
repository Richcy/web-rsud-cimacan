<!-- <li class="dropdown"><a class="<?=$dropdown_parent_irj?>" href="javascript:void();"><span>Instalasi Rawat Jalan</span> <i class="bi bi-chevron-right"></i></a>
                <ul>
                  <li>
                    <a class="<?=$cur_page=='klinik_anak' ? 'active' : '';?>" href="<?=base_url('klinik-anak.html');?>">Klinik Anak</a>
                  </li>
                  <li>
                    <a class="<?=$cur_page=='klinik_obgyn_dan_kebinanan' ? 'active' : '';?>" href="<?=base_url('klinik-obgyn-dan-kebinanan.html');?>">Klinik Obgyn dan Kebidanan</a>
                  </li>
                  <li>
                    <a class="<?=$cur_page=='klinik_gigi' ? 'active' : '';?>" href="<?=base_url('klinik-gigi.html');?>">Klinik Gigi</a>
                  </li>
                  <li>
                    <a class="<?=$cur_page=='klinik_dots' ? 'active' : '';?>" href="<?=base_url('klinik-dots.html');?>">Klinik DOTS</a>
                  </li>
                  <li>
                    <a class="<?=$cur_page=='klinik_penyakit_dalam' ? 'active' : '';?>" href="<?=base_url('klinik-penyakit-dalam.html');?>">Klinik Penyakit Dalam</a>
                  </li>
                  <li>
                    <a class="<?=$cur_page=='klinik_bedah' ? 'active' : '';?>" href="<?=base_url('klinik-bedah.html');?>">Klinik Bedah</a>
                  </li>
                    <li>
                      <a class="<?=$cur_page=='klinik_jiwa' ? 'active' : '';?>" href="<?=base_url('klinik-jiwa.html');?>">Klinik Jiwa</a>
                  </li>
                    <li>
                      <a class="<?=$cur_page=='klinik_vct' ? 'active' : '';?>" href="<?=base_url('klinik-vct.html');?>">Klinik VCT</a>
                  </li>
                </ul>
              </li> -->